<?php
    const BASE_URL = "http://localhost/pos_mvc/";
    const HOST = "localhost";
    const BD = "pos_mvc";
    const DB_USER = "root";
    const PASS = "";
    const CHARSET = "charset=utf8";
?>